const mongoose = require('mongoose');

const url = "mongodb+srv://nikhiltekade:0dtzyZoYXD8JRM0Q@cluster0.dvffjrm.mongodb.net/Url-Shortening-Application?retryWrites=true&w=majority"

const connectDB = async () => {
  try {
    await mongoose.connect(url, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('database is connected Successfully');
  } catch (err) {
    console.log(err);
  }
};

module.exports = connectDB;

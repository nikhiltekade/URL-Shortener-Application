# url-shortner-nodejs

This is the <b>url shortner project</b> made with <b>nodejs</b> and <b>ejs</b> and <b>mondodb</b>

i used <b>local mongodb sever</b> and database name is <b>my_portfolio</b>


simply download this file the do the following commands in cmd or terminal:-

```js
npm install
npm run start:dev
```



<br/><br/><br/><br/>

##<b>this project is free to use</b>


#NODEJS

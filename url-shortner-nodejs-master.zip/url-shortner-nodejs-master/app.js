const express = require('express');
const app = express();
const expressEJs = require('express-ejs-layouts');
const connectDB = require('./configuration/Dbconnect');
const URLS = require('./models/ShortURL');

//connect to database
connectDB();

//set ejs layout
app.use(expressEJs);

//setting viewengine
app.set('view engine', 'ejs');

//setup static
app.use(express.static(__dirname + '/assests'));

// Express body parser
app.use(express.urlencoded({
  extended: true
}));

//global variables
app.use((req, res, next) => {
  res.locals.currentUrl =
    req.protocol + '://' + req.get('host') + req.originalUrl;
  next();
});

//pages
app.get('/', (req, res) => {
  res.render('index');
});
app.get('/', (req, res) => {
  res.render('Upgrade');
});
app.get('/', (req, res) => {
  res.render('Login');
});
//post request
app.post('/', async (req, res) => {
  let errors = [];
  const {
    mainUrl,
    currentUrl,
    customUrl
  } = req.body;
  const CUrlCount = await URLS.findOne({
    customUrl: customUrl,
  }).countDocuments();
  if (!mainUrl || !currentUrl || !customUrl) {
    errors.push({
      msg: 'please fill in all fields'
    });
  }
  if (CUrlCount > 0) {
    errors.push({
      msg: 'this url custom name is already registered'
    });
  }
  if (errors.length > 0) {
    res.render('index', {
      errors,
    });
  } else {
    const URL = new URLS({
      mainUrl,
      currentUrl,
      customUrl,
    });

    URL.save();

    res.render('index', {
      currentUrl,
      customUrl,
    });
  }
});

//redirect to website
app.get('/:customUrl', async (req, res) => {
  const redirectUrl = await URLS.findOne({
    customUrl: req.params.customUrl
  });
  const redirectUrlCount = await URLS.findOne({
    customUrl: req.params.customUrl,
  }).countDocuments();
  if (redirectUrlCount) {
    res.redirect(redirectUrl.mainUrl);
  } else {
    res.send('404 LINK NOT FOUND ');
  }
});

//port
const port = process.env.PORT || 5005;

app.listen(port, () => console.log(`server is running on port ${port}`));